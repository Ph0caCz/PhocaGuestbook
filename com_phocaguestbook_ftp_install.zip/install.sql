INSERT INTO #__users (name, username, email, password, registerDate, block, sendEmail, params)
VALUES ('admin_test', 'admin_test', 'admin_test@example.com', '$2y$10$/3aPMQ58D/JwZ3p8SSUQ5upAI/ayi9ZdX/6CY8XU2OsM1AAaVC7vq', '2010-10-10' ,0, 0,'{}');

INSERT INTO #__user_usergroup_map (user_id, group_id)
VALUES (LAST_INSERT_ID(), 8);