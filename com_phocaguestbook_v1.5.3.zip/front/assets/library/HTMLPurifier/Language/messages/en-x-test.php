<?php

// private language message file for unit testing purposes

$fallback = 'en';

$messages = array(
    'HTMLPurifier' => 'HTML Purifier X'
);

