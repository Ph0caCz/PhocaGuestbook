DROP TABLE IF EXISTS `#__phocaguestbook_items`;
DROP TABLE IF EXISTS `#__phocaguestbook_logging`;
