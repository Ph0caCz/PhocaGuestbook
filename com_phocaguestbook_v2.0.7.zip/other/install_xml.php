<?php
/*********** XML PARAMETERS AND VALUES ************/
$xml_item = "component";// component | template
$xml_file = "phocaguestbook.xml";		
$xml_name = "com_phocaguestbook";
$xml_creation_date = "20/11/2012";
$xml_author = "Jan Pavelka (www.phoca.cz)";
$xml_author_email = "";
$xml_author_url = "www.phoca.cz";
$xml_copyright = "Jan Pavelka";
$xml_license = "GNU/GPL";
$xml_version = "2.0.7";
$xml_description = "Phoca Guestbook";
$xml_copy_file = 1;//Copy other files in to administration area (only for development), ./front, ./language, ./other
/*
$xml_menu = array (0 => "Phoca Guestbook", 1 => "option=com_phocaguestbook");
$xml_submenu[0] = array (0 => "Phoca Items", 1 => "option=com_phocaguestbook&amp;view=phocaguestbooks");
$xml_submenu[1] = array (0 => "Phoca Guestbooks", 1 => "option=com_phocaguestbook&amp;view=phocaguestbookbs");
*/

$xml_menu = array (0 => "COM_PHOCAGUESTBOOK", 1 => "option=com_phocaguestbook", 2 => "components/com_phocaguestbook/assets/images/icon-16-pgb-menu.png", 3 => "COM_PHOCAGUESTBOOK", 4 => 'phocaguestbookcp');

$xml_submenu[0] = array (0 => "COM_PHOCAGUESTBOOK_CONTROLPANEL", 1 => "option=com_phocaguestbook", 2 => "components/com_phocaguestbook/assets/images/icon-16-pgb-menu-cp.png", 3 => "COM_PHOCAGUESTBOOK_CONTROLPANEL", 4 => 'phocaguestbookcp');

$xml_submenu[1] = array (0 => "COM_PHOCAGUESTBOOK_ITEMS", 1 => "option=com_phocaguestbook&amp;view=phocaguestbooks", 2 => "components/com_phocaguestbook/assets/images/icon-16-pgb-menu-item.png", 3 => "COM_PHOCAGUESTBOOK_ITEMS", 4 => 'phocaguestbooks');

$xml_submenu[2] = array (0 => "COM_PHOCAGUESTBOOK_GUESTBOOKS", 1 => "option=com_phocaguestbook&amp;view=phocaguestbookbs", 2 => "components/com_phocaguestbook/assets/images/icon-16-pgb-menu-guestbook.png", 3 => "COM_PHOCAGUESTBOOK_GUESTBOOKS", 4 => 'phocaguestbookbs');

$xml_submenu[3] = array (0 => "COM_PHOCAGUESTBOOK_INFO", 1 => "option=com_phocaguestbook&amp;view=phocaguestbookin", 2 => "components/com_phocaguestbook/assets/images/icon-16-pgb-menu-info.png", 3 => "COM_PHOCAGUESTBOOK_INFO", 4 => 'phocaguestbookin');


$xml_install_file = 'install.phocaguestbook.php'; 
$xml_uninstall_file = 'uninstall.phocaguestbook.php';
/*********** XML PARAMETERS AND VALUES ************/
?>