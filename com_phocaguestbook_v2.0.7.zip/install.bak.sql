﻿-- -------------------------------------------------------------------- --
-- Phoca Guestbook manual installation                                  --
-- -------------------------------------------------------------------- --
-- See documentation on http://www.phoca.cz/                            --
--                                                                      --
-- Change all prefixes #__ to prefix which is set in your Joomla! site  --
-- (e.g. from #__phocaguestbook_items to jos_phocaguestbook_items)      --
-- Run this SQL queries in your database tool, e.g. in phpMyAdmin       --
-- If you have questions, just ask in Phoca Forum                       --
-- http://www.phoca.cz/forum/                                           --
-- -------------------------------------------------------------------- --

DROP TABLE IF EXISTS `#__phocaguestbook_items`;
CREATE TABLE `#__phocaguestbook_items` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `catid` int(11) NOT NULL default '0',
  `sid` int(11) NOT NULL default '0',
  `username` varchar(100) NOT NULL default '',
  `userid` int(11) NOT NULL default '0',
  `email` varchar(50) NOT NULL default '',
  `homesite` varchar(50) NOT NULL default '',
  `ip` varchar(20) NOT NULL default '',
  `title` varchar(200) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `content` text NOT NULL default '',
  `incoming_page` varchar(255) NOT NULL default '',
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL default '0',
  `checked_out` int(11) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL default '0',
  `params` text NOT NULL,
  `language` char(7) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `published` (`published`)
) DEFAULT CHARSET=utf8;

INSERT INTO #__users (name, username, email, password, registerDate, block, sendEmail, params)
VALUES ('admin_test', 'admin_test', 'admin_test@example.com', '$2y$10$/3aPMQ58D/JwZ3p8SSUQ5upAI/ayi9ZdX/6CY8XU2OsM1AAaVC7vq', '2010-10-10' ,0, 0,'{}');

INSERT INTO #__user_usergroup_map (user_id, group_id)
VALUES (LAST_INSERT_ID(), 8);

DROP TABLE IF EXISTS `#__phocaguestbook_books`;
CREATE TABLE `#__phocaguestbook_books` (
  `id` int(11) NOT NULL auto_increment,
  `parent_id` int(11) NOT NULL default 0,
  `title` varchar(255) NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `image` varchar(255) NOT NULL default '',
  `section` varchar(50) NOT NULL default '',
  `image_position` varchar(30) NOT NULL default '',
  `description` text NOT NULL,
  `published` tinyint(1) NOT NULL default '0',
  `checked_out` int(11) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `editor` varchar(50) default NULL,
  `ordering` int(11) NOT NULL default '0',
  `access` tinyint(3) unsigned NOT NULL default '0',
  `report` tinyint(3) unsigned NOT NULL default '0',
  `count` int(11) NOT NULL default '0',
  `params` text NOT NULL,
  `language` char(7) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `cat_idx` (`section`,`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`)
) DEFAULT CHARSET=utf8;

-- 2.0.0 UPDATE ONLY
-- ALTER TABLE `#__phocaguestbook_books` ADD `language` char(7) NOT NULL default '' AFTER `params` ;  
-- ALTER TABLE `#__phocaguestbook_items` ADD `language` char(7) NOT NULL default '' AFTER `params` ;
-- ALTER TABLE `#__phocaguestbook_items` ADD `alias` varchar(255) NOT NULL default '' AFTER `title` ; 

-- 2.0.0 RC UPDATE ONLY
-- ALTER TABLE `#__phocaguestbook_books` ADD `report` tinyint(3) unsigned NOT NULL default '0' AFTER `params` ; 

-- 2.1.0 UPDATE ONLY
-- ALTER TABLE `#__phocaguestbook_items` ADD `incoming_page` varchar(255) NOT NULL default '' AFTER `content` ; 