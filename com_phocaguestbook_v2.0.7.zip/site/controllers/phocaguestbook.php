<?php
/*
 * @package		Joomla.Framework
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU General Public License version 2 or later;
 */
defined('_JEXEC') or die();
jimport('joomla.mail.helper');

class PhocaGuestbookControllerPhocaGuestbook extends PhocaGuestbookController
{
	function __construct() {
		parent::__construct();
		$this->registerTask('submit', 'submit');
		$this->registerTask('delete', 'remove');
		$this->registerTask('unpublish', 'unpublish');
	}
	
	function display() {
		parent::display();
	}
	
	function submit() {
		
		$uri 		= &JFactory::getURI();
		$app 		= JFactory::getApplication();
		
		//All security settings moved to model
		$postNew	= array();
		$model		= $this->getModel( 'guestbook' );
		if ($model->store($postNew)) {
			if ($postNew['published'] == 0) {
				$msg = JText::_( 'COM_PHOCAGUESTBOOK_SUCCESS_SAVE_ITEM' ). ", " .JText::_( 'COM_PHOCAGUESTBOOK_REVIEW_MESSAGE' );
			} else {
				$msg = JText::_( 'COM_PHOCAGUESTBOOK_SUCCESS_SAVE_ITEM' );
			}
			$this->setRedirect($uri->toString(),$msg );
		} else {
			if (isset($postNew['displayformerror']) && $postNew['displayformerror'] == 1 ) {
				$this->display();
			} else if (isset($postNew['akismeterror']) && $postNew['akismeterror'] != '' ) {
				$msg = $postNew['akismeterror'];
				$this->setRedirect($uri->toString(),$msg );
			} else {
				$msg = JText::_( 'COM_PHOCAGUESTBOOK_ERROR_SAVE_ITEM' );
				$this->setRedirect($uri->toString(),$msg );
			}
		}

	}
	
	function remove() {
		$app	= JFactory::getApplication();
		$user 		= &JFactory::getUser();
		$cid 		= JRequest::getVar( 'mid', null, '', 'int' );
		$id 		= JRequest::getVar( 'id', null, '', 'int' );
		$itemid 	= JRequest::getVar( 'Itemid', null, '', 'int' );
		$limitstart = JRequest::getVar( 'limitstart', null, '', 'int' );
		$model 		= $this->getModel( 'guestbook' );
	
		$canAdmin	= PhocaguestbookHelperFront::canAdmin();
		if ($canAdmin) {

			if (count( $cid ) < 1) {
				JError::raiseError(500, JText::_( 'COM_PHOCAGUESTBOOK_WARNING_SELECT_ITEM_DELETE' ) );
			}
			if(!$model->delete($cid)) {
				echo "<script> alert('".$model->getError(true)."'); window.history.go(-1); </script>\n";
				$msg = JText::_( 'COM_PHOCAGUESTBOOK_ERROR_DELETE_ITEM' );
			} else {
				$msg = JText::_( 'COM_PHOCAGUESTBOOK_SUCCESS_DELETE_ITEM' );
			}
		} else {
			$msg = JText::_( 'COM_PHOCAGUESTBOOK_NOT_AUTHORIZED_DO_ACTION' );
		}
		// Limitstart (if we delete the last item from last pagination, this pagination will be lost, we must change limitstart)
		$countItem = $model->countItem($id);
		if ((int)$countItem[0] == $limitstart) {
			$limitstart = 0;
		}

		// Redirect
		$link	= 'index.php?option=com_phocaguestbook&view=guestbook&id='.$id.'&Itemid='.$itemid.'&limitstart='.$limitstart;
		$link	= JRoute::_($link, false);
		$this->setRedirect( $link, $msg );
	}
	
	function unpublish() {
		$app	= JFactory::getApplication();
		$user 		=& JFactory::getUser();
		$cid 		= JRequest::getVar( 'mid', null, '', 'int' );
		$id 		= JRequest::getVar( 'id', null, '', 'int' );
		$itemid 	= JRequest::getVar( 'Itemid', null, '', 'int' );
		$limitstart = JRequest::getVar( 'limitstart', null, '', 'int' );
		$model 		= $this->getModel( 'guestbook' );
		
		$canAdmin	= PhocaguestbookHelperFront::canAdmin();
		if ($canAdmin) {
			
			if (count( $cid ) < 1) {
				JError::raiseError(500, JText::_( 'COM_PHOCAGUESTBOOK_WARNING_SELECT_ITEM_UNPUBLISH' ) );
			}
			if(!$model->publish($cid, 0)) {
				echo "<script> alert('".$model->getError(true)."'); window.history.go(-1); </script>\n";
				$msg = JText::_( 'COM_PHOCAGUESTBOOK_ERROR_UNPUBLISH_ITEM' );
			}
			else {
				$msg = JText::_( 'COM_PHOCAGUESTBOOK_SUCCESS_UNPUBLISH_ITEM' );
			}
		} else {
			$msg = JText::_( 'COM_PHOCAGUESTBOOK_NOT_AUTHORIZED_DO_ACTION' );
		}
		
		// Limitstart (if we delete the last item from last pagination, this pagination will be lost, we must change limitstart)
		$countItem = $model->countItem($id);

		if ((int)$countItem[0] == $limitstart) {
			$limitstart = 0;
		}
		
		// Redirect
		$link	= 'index.php?option=com_phocaguestbook&view=guestbook&id='.$id.'&Itemid='.$itemid.'&limitstart='.$limitstart;
		$link	= JRoute::_($link, false);
		$this->setRedirect( $link, $msg );
	}
	
}
?>
